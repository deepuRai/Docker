# dockerize-php-sample
Run PHP Sample Application on Docker Container

This is a sample application used in Dockerizing PHP Application demo.

Please follow below links if you want to see how to dockerize this sample PHP application.

YouTube Video:
Blog Post: 
